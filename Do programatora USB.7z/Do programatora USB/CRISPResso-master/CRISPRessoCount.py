#!/usr/bin/env python
# -*- coding: utf-8 -*-


from CRISPResso.CRISPRessoCountCORE import main


if __name__ == '__main__':
    main()
