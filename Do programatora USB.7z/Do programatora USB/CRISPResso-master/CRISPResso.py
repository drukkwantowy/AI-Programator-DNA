#!/usr/bin/env python
# -*- coding: utf-8 -*-


from CRISPResso.CRISPRessoCORE import main


if __name__ == '__main__':
    main()
